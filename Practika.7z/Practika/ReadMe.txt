npm install

Сервер запускать - node server.js